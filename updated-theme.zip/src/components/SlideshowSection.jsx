// src/components/Slideshow.jsx
import React, { useEffect, useRef } from 'react';

const Slideshow = ({ slides }) => {
  const slideshowRef = useRef(null);

  useEffect(() => {
    const slideshow = slideshowRef.current;
    if (!slideshow) return;

    let index = 0;
    const slideElements = slideshow.querySelectorAll('.slide');
    
    const showSlide = (i) => {
      slideElements.forEach((slide, idx) => {
        slide.style.display = idx === i ? 'block' : 'none';
      });
    };

    showSlide(index);

    const nextSlide = () => {
      index = (index + 1) % slideElements.length;
      showSlide(index);
    };

    const interval = setInterval(nextSlide, 3000); // Change slide every 3 seconds

    return () => clearInterval(interval); // Cleanup on component unmount
  }, [slides]);

  return (
    <div className="slideshow" ref={slideshowRef}>
      {Object.keys(slides).map((key, index) => {
        const slide = slides[key];
        return (
          <div
            key={index}
            className="slide"
            
          >
           <img src={slide.image} alt="Custom" />
            <div className="slide-content">
              <h2>{slide.title}</h2>
              <p>{slide.description}</p>
            </div>
          </div>
        );
      })}
    </div>
  );
};

export default Slideshow;
