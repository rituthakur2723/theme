import React from 'react';

const Menu = ({ menuItems }) => {
  return (
    <nav>
      <ul className="flex space-x-4">
        {menuItems.map((item, index) => (
          <li key={index}>
            <a href={item.url} className="hover:underline">{item.title}</a>
          </li>
        ))}
      </ul>
    </nav>
  );
};

export default Menu;
