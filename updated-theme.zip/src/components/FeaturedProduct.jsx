import React from 'react';

const FeaturedProduct = ({ product }) => {
  const { title, price, image, handle } = product || {};

  return (




    
    <div id="hola-featured-product-react">
        <div id="hola-featured-image">
        <a href={`/products/${handle || ''}`}>
        <img
          src={image?.src || 'https://via.placeholder.com/300'}
          alt={title || 'No image available'}
          className="featured-product-image"
        />
        </a>
        </div>
        <div id="hole-featured-product-info">
        <a href={`/products/${handle || ''}`}>
        
        <h2 className="featured-product-title">{title || 'No title available'}</h2>
        <p className="featured-product-price">{price ? `${price}` : 'No price available'}</p>
      </a>
        </div>
      
    </div>
  );
};

export default FeaturedProduct;
