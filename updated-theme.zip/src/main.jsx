import './main.css';
import React from 'react';
import ReactDOM from 'react-dom';
import Header from './components/Header';
import ImageTextSection from './components/ImageTextSection';
import SiteLogo from './components/SiteLogo'; // Import SiteLogo if needed
import AnnouncmentBar from './components/AnnouncmentBar';
import SlideshowSection from './components/SlideshowSection'; 
import FeaturedProduct from './components/FeaturedProduct';

document.addEventListener('DOMContentLoaded', () => {
    const AnnouncmentBarDiv = document.getElementById('announcmentBar');
    if (AnnouncmentBarDiv) {
      ReactDOM.render(
        <AnnouncmentBar settings={window.AnnouncmentBarSettings} />,
        AnnouncmentBarDiv
      );
    }


    const imageTextSectionDiv = document.getElementById('image-text-section');
    if (imageTextSectionDiv) {
      ReactDOM.render(
        <ImageTextSection settings={window.imageTextSectionSettings} />,
        imageTextSectionDiv
      );
    }

    const headerDiv = document.getElementById('header-react');
  
  if (headerDiv) {
    const settings = window.headerSettings || {}; // Default to an empty object if not defined
    ReactDOM.render(<Header settings={settings} />, headerDiv);
  }

  const slideshowSectionDiv = document.getElementById('slideshow-section');
  if (slideshowSectionDiv) {
    const slides = window.slideshowSettings?.slides || {};
    ReactDOM.render(<SlideshowSection slides={slides} />, slideshowSectionDiv);
  }

  const productData = window.FeaturedProductData?.product || {};

ReactDOM.render(
  <FeaturedProduct product={productData} />,
  document.getElementById('featured-product')
);
});
