import React from 'react';
import SiteLogo from './SiteLogo';
import Menu from './Menu'; // Import the Menu component

const Header = ({ settings }) => {
    if (!settings) {
      return <div>Loading...</div>; // Handle the case where settings are not yet available
    }
  
    return (
      <header className="header-main">
        <div className="container">
          <div className="header-logo flex items-center">
            <SiteLogo settings={settings} />
          </div>
          <div className="header-nav">
            <nav>
              <ul className="flex space-x-4">
                {settings.menuItems && settings.menuItems.map((item, index) => (
                  <li key={index}>
                    <a href={item.url} className="hover:underline">{item.title}</a>
                  </li>
                ))}
              </ul>
            </nav>
          </div>
        </div>
      </header>
    );
  };

export default Header;
